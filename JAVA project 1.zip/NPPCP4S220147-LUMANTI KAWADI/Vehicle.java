
/**
 * Write a description of class Vehicle here.
 *
 * @author (NP01CP4S220147 LUMANTI KAWADI)
 * @version (1.0.0)
 */

//creating super class Vehicle
public class Vehicle
{
  private int vehicleID;
  private String vehicleName;
  private String vehicleWeight;
  private String vehicleColor;
  private String vehicleSpeed;
  
  // Defining the parameterized Constructor 
  public Vehicle (int vehicleID, String vehicleName, String vehicleColor, String vehicleWeight){
      this.vehicleID= vehicleID;
      this.vehicleName= vehicleName;
      this.vehicleColor= vehicleColor;
      this.vehicleWeight= vehicleWeight;
      this.vehicleSpeed = "";
    }
    
    /*This method gives the value of vehicleID attribute  */
  public int getVehicleID(){
      return this.vehicleID;
  }
  /*This method gives the value of vehicleName attribute */
  public String getVehicleName(){
      return this.vehicleName;
  }
    /*This method gives the value of vehicleColor attribute */
  public String getVehicleColor(){
      return this.vehicleColor;
  }  
      /*This method gives the value of vehicleSpeed attribute */
   public String getVehicleSpeed(){
      return this.vehicleSpeed;
  }  
  /*This method gives the value of vehicleWeight attribute */
  public String getVehicleWeight(){
      return this.vehicleWeight;
  }  
  
  /*This method is used to set the speed of a vehicle from its parameter as newSpeed */
  public void setVehicleSpeed( String newSpeed){
      this.vehicleSpeed= newSpeed;
  }
  /*This method is used to set the speed of a vehicle from its parameter as newColor */
  public void setVehicleColor(String newColor){
      this.vehicleColor= newColor;
  }
  
  /*This method displays the output of each attributes */
  public void display(){
      System.out.println("vehicle ID: " + this.vehicleID);
      System.out.println("vehicle Name: " + this.vehicleName);
      System.out.println("vehicle Weight: " + this.vehicleWeight);
      System.out.println("vehicle Color: "+ this.vehicleColor);
      System.out.println("vehicle Speed: " + this.vehicleSpeed);
       if(this.vehicleWeight==""){
           System.out.println("vehicleweight value is not given");
       }
   
   }
} 

  
      
  

