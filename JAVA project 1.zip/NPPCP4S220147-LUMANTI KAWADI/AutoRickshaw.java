
/**
 * Write a description of class AutoRickshaw here.
 *
 * @author (NP01CP4S220147 LUMANTI KAWADI)
 * @version (1.0.0)
 */
//Creating sub-class AutoRickshaw
public class AutoRickshaw extends Vehicle
{
    private int engineDisplacement;
    private String torque;
    private int numberOfSeats;
    private int fuelTankCapacity;
    private String groundClearance;
    private int chargeAmount;
    private String bookedDate;
    private boolean isBooked;
    //Defining the parameterized Constructor
    public AutoRickshaw(int vehicleID, String vehicleName, String vehicleWeight,String torque, String vehicleColor, String vehicleSpeed, int engineDisplacement, int fuelTankCapacity,String groundClearance){
        super(vehicleID, vehicleName, vehicleColor, vehicleWeight);
        this.engineDisplacement= engineDisplacement;
        this.torque= torque;
        this.fuelTankCapacity= fuelTankCapacity;
        this.groundClearance= groundClearance;
        super.setVehicleSpeed(vehicleSpeed);
        super.setVehicleColor(vehicleColor);
        this.isBooked= false;
    }
    /*This is an accessor method the gets the value stored in engineDisplacement  attribute */
    public int getEngineDisplacement(){
        return this.engineDisplacement;
    }
    /*This is an accessor method the gets the value stored in torque attribute */
    public String getTorque(){
        return this.torque;
    }
    /*This is an accessor method the gets the value stored in numberOfSeats attribute */
    public int getNumberOfSeats(){
        return this.numberOfSeats;
    }
    /*This is an accessor method the gets the value stored in fuelTankCapacity attribute */
    public int getFuelTankCapacity(){
        return this.fuelTankCapacity;
    }
    /*This is an accessor method the gets the value stored in groundClearance attribute */
    public String getGroundClearance(){
        return this. groundClearance;
    }
    /*This is an accessor method the gets the value stored in chargeAmount attribute */
    public int getChargeAmount(){
        return this.chargeAmount;
    }
    /*This is an accessor method the gets the value stored in bookedDate attribute */
    public String getbookedDate(){
        return this.bookedDate;
    }
    /*This is an accessor method the gets the value stored in isBooked attribute */
    public boolean getIsBooked(){
        return this.isBooked;
    }
    /*This is a mutator method that accepts a parameter as newChargeAmount and sets value in chargeAmount attribute form its parameter. */
    public void setChargeAmount(int newChargeAmount){
        this.chargeAmount=newChargeAmount;
    }
    /*This is a mutator method that accepts a parameter as newNumberOfSeats and sets value in numberOfSeats attribute form its parameter. */
    public void setNumberOfSeats(int newNumberOfSeats){
        this.numberOfSeats=newNumberOfSeats;
    }
    /*This method is for booking the AutoRickshaw.It accepts parameters as bookedDate, chargeAmount and numberOfSeats. 
     * It books an AutoRickshaw as per the instructions and also lets the user knowwhether the AutoRickshaw in booked or
     * not with proper annotations. */
    public void BookAutoRickshaw(String bookedDate,int chargeAmount, int numberOfSeats){
        if(this.isBooked== false){
            this.bookedDate = bookedDate;
            setChargeAmount(chargeAmount);
            setNumberOfSeats(numberOfSeats);
            this.isBooked = true;
            System.out.println("Autorickshaw" +super.getVehicleID() +"is now booked");
            
        }else{
            System.out.println("isBooked = "+this.isBooked);
            System.out.println("AutoRickshaw" +super.getVehicleID() +"is already booked");
        }
    }
    /*This method is for booking the AutoRickshaw.It accepts parameters as bookedDate, chargeAmount and numberOfSeats.
     * It books an AutoRickshaw as per the instructions and also lets the user know whether the AutoRickshaw in booked or
     * not with proper annotations. */
    public void display(){
        super.display();
        if(isBooked==true){
            System.out.println("EngineDisplacement= " + this.engineDisplacement);
            System.out.println("Torque= "+this.torque);
            System.out.println("FuelTankCapacity= "+this.fuelTankCapacity);
            System.out.println("GroundClearance= "+this.groundClearance);
            System.out.println("BookedDate= "+this.bookedDate);
        }
    
        if(this.chargeAmount==0){
            System.out.println("Charge amount has not been set");
        }else{
            System.out.println("ChargeAmount= "+this.chargeAmount);
        }
        if(this.numberOfSeats==0){
            System.out.println("number of seats not set");
        }else{
            System.out.println("numberofseats= "+this.numberOfSeats);
        }
    }
}
    
    
        
        
        
        

