
/**
 * Write a description of class ElectricScooter here.
 *
 * @author (NP01CP4S220147 LUMANTI KAWADI)
 * @version (1.0.0)
 */
//Creating sub-class ElectricScooter
public class ElectricScooter extends Vehicle
{
  private int range;
  private int batteryCapacity;
  private int price;
  private String chargingTime;
  private String brand;
  private String mileage;
  private boolean hasPurchased;
  private boolean hasSold;
  // Defining the parameterized Constructor
  public ElectricScooter(int VehicleID,String vehicleName,String vehicleWeight,String vehicleSpeed,String VehicleColor,int BatteryCapacity){
      super(VehicleID,vehicleName,VehicleColor,vehicleWeight);
      super.setVehicleColor(VehicleColor);
      super.setVehicleSpeed(vehicleSpeed);
      this.batteryCapacity= batteryCapacity;
      this.range = 0;
      this.price = 0;
      this.brand = "";
      this.mileage = "";
      this.chargingTime = "";
      this.hasPurchased = false;
      this.hasSold = false;
  }
  /*This is an accessor method the gets the value stored in range  attribute */
  public int getRange(){
      return this.range;
  }
  /*This is an accessor method the gets the value stored in range  attribute */
  public int getBatteryCapacity(){
      return this.batteryCapacity;
  }
  /*This is an accessor method the gets the value stored in price  attribute */
  public int getPrice(){
      return this.price;
  }
  /*This is an accessor method the gets the value stored in chargingTime attribute */
  public String getChargingTime(){
      return this.chargingTime;
  }
  /*This is an accessor method the gets the value stored in brand attribute */
  public String getBrand(){
      return this.brand;
  }
    /*This is an accessor method the gets the value stored in mileage attribute */
   public String getMileage(){
      return this.mileage;
  }
  /*This is an accessor method the gets the value stored in hasPurchased attribute */
   public boolean isHasPurchased(){
      return this.hasPurchased;
  }
  /*This is an accessor method the gets the value stored in hasSold attribute */
   public boolean isHasSold(){
      return this.hasSold;
  }
  /*This is a mutator method that accepts a parameter as newBarnd and sets value in brand attribute form its parameter. */
  public void setBrand(String newBrand){
      if(!this.hasPurchased){
          this.brand = newBrand;
      }
      else{
          System.out.println("Brand cannot be changed");
      }
  }
  /*This method is for purchasing the ElectricScooter. It accepts parameters as brand, price, chargingTime, mileage, and range. 
   * This methods helps purchase the ElectricScooter as per instructed and lets user know if the ElectricScooter is already purchased 
   * or not. */
  public void purchaseElectricScooter(String brand, int price, String ChargingTime, String mileage, int range){
      if(!this.hasPurchased){
          setBrand(brand);
          this.price = price;
          this.chargingTime = chargingTime;
          this.mileage = mileage;
          this.range = range;
          this.hasPurchased = true;
      }
      else{
          System.out.println("The scooter " +super.getVehicleID()+" has already been purchased.");
      }
  }
  /*This method is for selling the ElectricScooter. It accepts a parameter as newprice. This methods helps sell the ElectricScooter
   * as per instructed and lets user know if the ElectricScooter has been purchased or not, or has been already sold or not. */
  public void sellElectricScooter(int newPrice){
      if(!this.hasSold){
              this.price = newPrice;
              this.chargingTime = "";
              this.mileage = "";
              this.batteryCapacity = 0;
              this.range = 0;
              this.hasSold = true;
              this.hasPurchased = false;
      }
      else{
          System.out.println("The scooter "+super.getVehicleID() +" is already sold");
      }
  }
    /*This method displays the output of each attributes of ElectricScooter class and Vehicle class, if the ElectricScooter is purchased,
     * with suitable annotations.  Otherwise it only calls the display() method of super class. */
    public void display()
    {
        super.display();
        if(this.hasPurchased){
            System.out.println("Brand: "+ this.brand);
            System.out.println("Battery Capacity: " + this.batteryCapacity);
            System.out.println("mileage: "+ this.mileage);
            System.out.println("range: "+ this.range);
            System.out.println("Charging Time: "+ this.chargingTime);
        }
    }
}
            
          
      
  
  
  
  
  
  
  
  
  
  
  
